"""
Step 6: Query the Database
--------------------------
Examples of useful SQL queries on the music library database.
"""

import sqlite3
import pandas as pd

# ========== CONFIGURATION ==========
db_file = "/storage/emulated/0/Download/my_music_library.db"
# ===================================

conn = sqlite3.connect(db_file)

print("=== 1. Total number of songs ===")
print(pd.read_sql("SELECT COUNT(*) AS total_songs FROM songs", conn))
print()

print("=== 2. Top 10 Artists ===")
print(pd.read_sql("""
    SELECT artist, COUNT(*) AS number_of_songs
    FROM songs
    GROUP BY artist
    ORDER BY number_of_songs DESC
    LIMIT 10
""", conn))
print()

print("=== 3. Longest 5 songs ===")
print(pd.read_sql("""
    SELECT title, artist, ROUND(duration_sec / 60.0, 1) AS duration_min
    FROM songs
    ORDER BY duration_sec DESC
    LIMIT 5
""", conn))
print()

print("=== 4. Total library size (GB) ===")
print(pd.read_sql("""
    SELECT ROUND(SUM(filesize_mb) / 1024.0, 2) AS total_size_gb
    FROM songs
""", conn))
print()

print("=== 5. Total listening time (hours) ===")
print(pd.read_sql("""
    SELECT ROUND(SUM(duration_sec) / 3600.0, 1) AS total_hours
    FROM songs
""", conn))
print()

print("=== 6. Average song duration (minutes) ===")
print(pd.read_sql("""
    SELECT ROUND(AVG(duration_sec) / 60.0, 1) AS avg_duration_min
    FROM songs
""", conn))

conn.close()
