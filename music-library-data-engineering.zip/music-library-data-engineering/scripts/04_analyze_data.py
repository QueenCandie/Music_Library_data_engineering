"""
Step 4: Analyze the Data
------------------------
Performs basic exploratory analysis on the cleaned music library.
"""

import pandas as pd

# ========== CONFIGURATION ==========
input_file = "/storage/emulated/0/Download/my_music_catalog_final_v2.csv"
# ===================================

df = pd.read_csv(input_file)

print("=== MUSIC LIBRARY ANALYSIS ===\n")

# Basic Overview
print("Total songs:", len(df))
print("Total library size: {:.2f} GB".format(df['filesize_mb'].sum() / 1024))
print("Average song size: {:.2f} MB".format(df['filesize_mb'].mean()))
print("Average song duration: {:.1f} minutes".format(df['duration_sec'].mean() / 60))
print("Total listening time: {:.1f} hours".format(df['duration_sec'].sum() / 3600))
print()

# Top Artists
print("=== TOP 15 ARTISTS ===")
print(df['artist'].value_counts().head(15))
print()

# Top Genres
print("=== TOP GENRES ===")
print(df['genre'].value_counts().head(10))
print()

# Duration Distribution
print("=== DURATION DISTRIBUTION ===")
df['duration_min'] = df['duration_sec'] / 60

def duration_group(minutes):
    if minutes < 2:
        return "Less than 2 min"
    elif minutes < 3:
        return "2 - 3 min"
    elif minutes < 4:
        return "3 - 4 min"
    elif minutes < 5:
        return "4 - 5 min"
    else:
        return "More than 5 min"

df['duration_group'] = df['duration_min'].apply(duration_group)
print(df['duration_group'].value_counts().sort_index())
print()

# Storage by Artist
print("=== STORAGE BY ARTIST (Top 10) ===")
artist_size = (
    df.groupby('artist')['filesize_mb']
    .agg(['count', 'sum'])
    .reset_index()
)
artist_size.columns = ['artist', 'number_of_songs', 'total_size_mb']
artist_size = artist_size.sort_values('total_size_mb', ascending=False)
print(artist_size.head(10))
print()

# Longest songs
print("=== TOP 5 LONGEST SONGS ===")
longest = df.sort_values('duration_sec', ascending=False)[['title', 'artist', 'duration_sec']].head(5)
longest['duration_min'] = (longest['duration_sec'] / 60).round(1)
print(longest[['title', 'artist', 'duration_min']])
