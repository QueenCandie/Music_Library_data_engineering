"""
Step 5: Create SQLite Database
------------------------------
Loads the final cleaned CSV and stores it in a SQLite database.
"""

import sqlite3
import pandas as pd

# ========== CONFIGURATION ==========
input_file = "/storage/emulated/0/Download/my_music_catalog_final_v2.csv"
db_file = "/storage/emulated/0/Download/my_music_library.db"
# ===================================

# Load the clean data
df = pd.read_csv(input_file)

# Create (or open) the SQLite database
conn = sqlite3.connect(db_file)

# Write the data into a table called "songs"
df.to_sql("songs", conn, if_exists="replace", index=False)

# Verify
cursor = conn.cursor()
cursor.execute("SELECT COUNT(*) FROM songs")
count = cursor.fetchone()[0]

print("Number of songs in database:", count)

print("\n=== Sample of data in the database ===")
sample = pd.read_sql("SELECT title, artist, duration_sec FROM songs LIMIT 5", conn)
print(sample)

print("\nDatabase created successfully!")
print(f"Location: {db_file}")

conn.close()
