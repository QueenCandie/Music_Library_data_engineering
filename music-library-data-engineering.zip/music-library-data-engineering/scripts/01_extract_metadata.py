"""
Step 1: Extract Metadata from MP3 Files
---------------------------------------
This script scans a folder (and all subfolders) for MP3 files,
extracts metadata using tinytag, and saves the result as a CSV.
"""

import os
from tinytag import TinyTag
import pandas as pd

# ========== CONFIGURATION ==========
# Change this path to the folder containing your MP3 files
music_folder = "/storage/emulated/0/Download/"
output_file = "/storage/emulated/0/Download/my_music_catalog.csv"
# ===================================

songs_data = []

print("Starting to scan your songs (including subfolders)...")
print("Please wait...\n")

# os.walk goes into every folder and subfolder
for root, dirs, files in os.walk(music_folder):
    for file in files:
        if file.lower().endswith(".mp3"):
            file_path = os.path.join(root, file)

            try:
                tag = TinyTag.get(file_path)

                song_info = {
                    "filename": file,
                    "title": tag.title,
                    "artist": tag.artist,
                    "album": tag.album,
                    "genre": tag.genre,
                    "year": tag.year,
                    "duration_sec": round(tag.duration, 2) if tag.duration else None,
                    "bitrate": tag.bitrate,
                    "filesize_mb": round(os.path.getsize(file_path) / (1024 * 1024), 2),
                    "full_path": file_path
                }

                songs_data.append(song_info)
                print(f"Processed: {file}")

            except Exception as e:
                print(f"Could not read: {file}")

# Convert list of dictionaries into a table (DataFrame)
df = pd.DataFrame(songs_data)

# Save as CSV
df.to_csv(output_file, index=False)

print("\n-----------------------------")
print("Finished!")
print(f"Total songs found: {len(df)}")
print(f"File saved at: {output_file}")
print("-----------------------------")
