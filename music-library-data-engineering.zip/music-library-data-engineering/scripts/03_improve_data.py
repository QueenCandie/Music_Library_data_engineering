"""
Step 3: Improve Data Quality
----------------------------
- Removes very short (broken) songs
- Tries to extract better Artist and Title from the filename
- Flags very long songs
"""

import pandas as pd
import re

# ========== CONFIGURATION ==========
input_file = "/storage/emulated/0/Download/my_music_catalog_clean.csv"
output_file = "/storage/emulated/0/Download/my_music_catalog_final_v2.csv"
# ===================================

df = pd.read_csv(input_file)

print("Songs before improvement:", len(df))

# 1. Remove very short songs (usually incomplete downloads)
df = df[df['duration_sec'] >= 30]
print("Songs after removing very short ones:", len(df))


def improve_artist_and_title(filename, current_artist, current_title):
    """
    Try to extract a better artist and title from the filename
    when the original metadata is missing or poor.
    """
    name = filename.replace(".mp3", "").replace(".MP3", "")

    # Remove common website names and junk
    name = re.sub(r'\|\|.*', '', name)
    name = re.sub(r'\|.*', '', name)
    name = re.sub(r'via[- ].*', '', name, flags=re.IGNORECASE)
    name = re.sub(r'www\..*', '', name)
    name = re.sub(r'TrendyBeatz\.com', '', name, flags=re.IGNORECASE)
    name = re.sub(r'Naijafinix\.com', '', name, flags=re.IGNORECASE)
    name = re.sub(r'CeeNaija\.com', '', name, flags=re.IGNORECASE)
    name = re.sub(r'\(Lyrics\)', '', name, flags=re.IGNORECASE)
    name = re.sub(r'\(Official Audio\)', '', name, flags=re.IGNORECASE)
    name = name.strip(" -_|().")

    # Try common separators
    artist = current_artist
    title = current_title

    if current_artist == "Unknown Artist":
        for sep in [" - ", "_-_", " – ", "-", "_"]:
            if sep in name:
                parts = name.split(sep, 1)
                possible_artist = parts[0].replace("_", " ").strip()
                possible_title = parts[1].replace("_", " ").strip() if len(parts) > 1 else name

                # Basic validation
                if 2 < len(possible_artist) < 40:
                    artist = possible_artist
                    title = possible_title
                break

    # Clean title a bit more
    title = re.sub(r'\|\|.*', '', str(title))
    title = re.sub(r'\|.*', '', title)
    title = title.strip(" -_|")

    return artist, title


# Apply the improvement
df[['artist', 'title']] = df.apply(
    lambda row: pd.Series(
        improve_artist_and_title(row['filename'], row['artist'], row['title'])
    ),
    axis=1
)

# Flag very long songs (more than 15 minutes)
df['is_very_long'] = df['duration_sec'] > 900

print("Unknown Artists remaining:", (df['artist'] == "Unknown Artist").sum())
print("Number of very long songs:", df['is_very_long'].sum())

# Save the improved version
df.to_csv(output_file, index=False)

print("\nImproved file saved at:", output_file)
print("\n=== Sample of improved data ===")
print(df[['title', 'artist', 'duration_sec']].head(10))
