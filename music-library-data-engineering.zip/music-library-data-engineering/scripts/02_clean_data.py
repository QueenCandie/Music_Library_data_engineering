"""
Step 2: Clean the Data
----------------------
This script loads the raw extracted data and fixes missing values.
"""

import pandas as pd

# ========== CONFIGURATION ==========
input_file = "/storage/emulated/0/Download/my_music_catalog.csv"
output_file = "/storage/emulated/0/Download/my_music_catalog_clean.csv"
# ===================================

# Load the raw data
df = pd.read_csv(input_file)

print("Original number of songs:", len(df))
print("\n--- Missing values before cleaning ---")
print(df.isnull().sum())

# ----- Cleaning Steps -----

# 1. If title is missing, use the filename (without .mp3)
df['title'] = df['title'].fillna(df['filename'].str.replace('.mp3', '', regex=False))
df['title'] = df['title'].str.strip()

# 2. If artist is missing, put "Unknown Artist"
df['artist'] = df['artist'].fillna("Unknown Artist")
df['artist'] = df['artist'].str.strip()

# 3. If genre is missing, put "Unknown"
df['genre'] = df['genre'].fillna("Unknown")
df['genre'] = df['genre'].str.strip()

# 4. If album is missing, put "Unknown Album"
df['album'] = df['album'].fillna("Unknown Album")
df['album'] = df['album'].str.strip()

# 5. If year is missing, put "Unknown"
df['year'] = df['year'].fillna("Unknown")

# 6. Remove exact duplicate files
df = df.drop_duplicates(subset=['filename'])

print("\nNumber of songs after cleaning:", len(df))
print("\n--- Missing values after cleaning ---")
print(df.isnull().sum())

# Save the cleaned version
df.to_csv(output_file, index=False)

print("\nCleaned file saved at:", output_file)
